##Calculator
work = ("start")
while work == ("start"):
    num1 = input("First Number: ")
    num2 = input("Second Number: ")
    print("What operation do you wish to perform?")
    operation = input("E.g. x, /, +, -, ^. ")
    if operation == "x":
        output = int(num1) * int(num2)
        print(output)
    elif operation == "/":
        output = int(num1) / int(num2)
        print(output)
    elif operation == "+":
        output = int(num1) + int(num2)
        print(output)
    elif operation == "-":
        output = int(num1) - int(num2)
        print(output)
    elif operation == "^":
        output = int(num1) ** int(num2)
        print(output)
    again = input("Do you wish to perform another action? ")
    if again == 'no':
        work = ("end")
        exit()