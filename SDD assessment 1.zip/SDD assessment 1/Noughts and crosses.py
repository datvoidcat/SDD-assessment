import random
print "this is the grid, to win choose three spaces in a line. for example 0, 1 and 2"
print "[0][1][2] "
print "[3][4][5] "
print "[6][7][8] "
list = [0, 1, 2, 
        3, 4, 5, 
        6, 7, 8]
def show():
    print "[0][1][2] "
    print "[3][4][5] "
    print "[6][7][8] "
def checkLine(char, spot1, spot2, spot3):
    if list[spot1] == char and list[spot2] == char and list[spot3] == char:
        return True
def checkALL (char):
    if checkLine(char, 0, 1, 2):
        True
    if checkLine(char, 3, 4, 5):
        True
    if checkLine(char, 6, 7, 8):
        True
    if checkLine(char, 1, 4, 8):
        True
    if checkLine(char, 1, 4, 8):
        True
    if checkLine(char, 1, 4, 8):
        True
    if checkLine(char, 1, 4, 8):
        True
    
while True:
    input = raw_input ("choose a number from 0-8 ")
    input = int(input)
    if list[input] != "x" and list[input] != "o":
        list[input] = "x"
        if checkALL ('x') == True:
            print "X WINS!"
            break;
        while True:
            random.seed()
            AI = random.randint(1,8) 
            if list[AI] != "o" and list[AI] != "x":
                list[AI] = "o"
                if checkALL ('o') == True:
                    print "O WINS!"                    
                    break;
                break;
    else:
        print "there is something here, please chose another spot"
    show()