import random

name = input("What is your name ")
print("Welcome to hangman ")
players = input("Would you like to play with 1 or 2 players? ")
if players == str(1):
    with open("Setwords.txt", "r") as file: 
        allText = file.read() 
        words = list(map(str, allText.split()))     
        word = (random.choice(words))
        print(word)
elif players == 2:
    word = input("Enter the word to be guessed ")
length = len(word)
print("\n"*20)
print("There are ", str(length), " letters in the word")
turns = 11
guessed = ''

while turns > 0:
    wrong = 0
    for char in word:
        if char in guessed:
            print(char,)
        else:
            print("_")
            wrong += 1
    if wrong == 0:
        print ("congratulations, you win!")
        exit()
    print
    
    guess = input("Guess a letter ->")
    guessed += guess
    if guess not in word:
        turns -= 1
        print ("That guess was wrong")
        print ("You guessed: " + guess)
        print ("you have" ,turns, "more lives left")
        if turns == 10:
            print (' ')
            print ('                ')
            print ('                ')
            print ('                ')
            print ('               ' )
            print ('                ')
            print (' ')
            print ('______________'   )
        if turns == 9:
            print (' ')
            print ('|                ')
            print ('|                ')
            print ('|                ')
            print ('|               ' )
            print ('|                ')
            print ('|')
            print ('|______________'   )
        if turns == 8:
            print ('________________')
            print ('|               ')
            print ('|               ')
            print ('|               ')
            print ('|               ' )
            print ('|                ')
            print ('|')
            print ('|______________')
        if turns == 7:
            print ('________________')
            print ('|               |')
            print ('|               ')
            print ('|               ')
            print ('|               ' )
            print ('|                ')
            print ('|')
            print ('|______________')
        if turns == 6:
            print ('________________')
            print ('|               |')
            print ('|               |')
            print ('|               ')
            print ('|               ' )
            print ('|                ')
            print ('|')
            print ('|______________'   )
        if turns == 5:
            print ('________________')
            print ('|               |')
            print ('|               |')
            print ('|               o')
            print ('|               ' )
            print ('|                ')
            print ('|')
            print ('|______________')
        if turns == 4:
            print ('________________')
            print ('|               |')
            print ('|               |')
            print ('|               o')
            print ('|                \ ' )
            print ('|                ')
            print ('|')
            print ('|______________')
        if turns == 3:
            print ('________________')
            print ('|               |')
            print ('|               |')
            print ('|               o')
            print ('|               |\ ' )
            print ('|                ')
            print ('|')
            print ('|______________')
        if turns == 2:
            print ('________________')
            print ('|               |')
            print ('|               |')
            print ('|               o')
            print ('|              /|\ ' )
            print ('|                ')
            print ('|')
            print ('|______________')
        if turns == 1:
            print ('________________')
            print ('|               |')
            print ('|               |')
            print ('|               o')
            print ('|              /|\ ' )
            print ('|              / ')
            print ('|')
            print ('|______________')
        if turns == 0:
            print ('________________')
            print ('|               |')
            print ('|               |')
            print ('|               o')
            print ('|              /|\ ' )
            print ('|              / \ ')
            print ('|')
            print ('|______________')
            print ('You lose.')
            print ("The word was " + word)
            exit()
